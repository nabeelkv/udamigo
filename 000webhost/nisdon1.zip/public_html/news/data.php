<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Read Data</title>
<?php
 
 include("init.php");
 $dbQueries = new dbQueries;
 
  $dbQueries->Query("SELECT * FROM data");
                           
  $datas = $dbQueries->fetchAll();
  $rowCount = $dbQueries->rowCount();
                           
  foreach($datas as $id=>$data) {
      echo ($id+1).') '. $data->title . '<br>';
  }
        
?>