<?php

include("init.php");
$dbQueries = new dbQueries;

include("includes/header.php");
?>

<body id="yDmH0d" jscontroller="pjICDe" jsaction="rcuQ6b:npT2md; click:FAbpgf; auxclick:FAbpgf;wINJic:.CLIENT;c0v8t:.CLIENT;UjQMac:.CLIENT;keydown:.CLIENT;keyup:.CLIENT;keypress:.CLIENT;nHjqDd:.CLIENT;LhiQec:.CLIENT;GvneHb:.CLIENT;qako4e:.CLIENT;gDJ6Jc:.CLIENT;b18Zgf:.CLIENT;tE0Tse:.CLIENT;u0pjoe:.CLIENT" class="tQj5Y ghyPEc IqBfM e2G3Fb b30Rkd hDsSPc V4dW0 k1PYFe hZmmCc EIlDfe d8Etdd LcUz9d" data-has-footer="true" style="min-height: 851px;" jslog="95013" data-new-gr-c-s-check-loaded="14.1057.0" data-gr-ext-installed="">
	<div class="VUoKZ" aria-hidden="true" style="user-select: auto;">
		<div class="TRHLAc" style="user-select: auto;"></div>
	</div>
	<div aria-hidden="true" class="xIZ6Le" style="user-select: auto;"></div>
	<div class="glbvKf" style="user-select: auto;"></div>
	<div class="pGxpHc" style="user-select: auto;">
		<!-- Nabeel -->
		<header style="display:none;" class="gb_na gb_2a gb_Re gb_Nd gb_Od tabletOrMobileDevice gb_oa" ng-non-bindable="" id="gb" role="banner">
			<div class="gb_7d" style="user-select: auto;">
				
			<div class="gb_Jc gb_Hc gb_oa" ng-non-bindable="" style="overflow-y: auto; user-select: auto; height: calc(851px - 100%);">
					<div class="gb_Sc" style="user-select: auto;">
						<div class="gb_tc" style="user-select: auto;">
							<div class="gb_uc" style="user-select: auto;"><a class="gb_ke gb_vc gb_ie" aria-label="വാർത്തകൾ" href="./?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" title="വാർത്തകൾ" style="user-select: auto;"><span class="gb_zc gb_he" aria-hidden="true" style="user-select: auto;"></span><span class="gb_5d gb_2c" style="user-select: auto;">വാർത്തകൾ</span></a></div>
						</div>
					</div>
					<div class="gb_Oc" style="user-select: auto;"></div>
				</div></div>
			<div class="gb_Md gb_3d gb_Sd gb_Ze" style="user-select: auto;">
				<div class="gb_Ld gb_3c gb_4c" style="user-select: auto;">
					<div class="gb_Ac" aria-expanded="false" aria-label="പ്രധാന മെനു" role="button" tabindex="0" style="user-select: auto;">
						<svg focusable="false" viewBox="0 0 24 24" style="user-select: auto;">
							<path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" style="user-select: auto;"></path>
						</svg>
					</div>
					<div class="gb_Ac gb_Dc gb_ya" aria-label="മടങ്ങുക" role="button" tabindex="0" style="user-select: auto;">
						<svg focusable="false" viewBox="0 0 24 24" style="user-select: auto;">
							<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" style="user-select: auto;"></path>
						</svg>
					</div>
					<div class="gb_Ac gb_Ec gb_ya" aria-label="അടയ്&zwnj;ക്കുക);" role="button" tabindex="0" style="user-select: auto;">
						<svg viewBox="0 0 24 24" style="user-select: auto;">
							<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" style="user-select: auto;"></path>
						</svg>
					</div>
					<div class="gb_tc" style="user-select: auto;">
						<div class="gb_uc" style="user-select: auto;"><a class="gb_ke gb_vc gb_ie" aria-label="വാർത്തകൾ" href="./?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" title="വാർത്തകൾ" id="sdgBod" style="user-select: auto;"><span class="gb_zc gb_he" aria-hidden="true" style="user-select: auto;"></span><span class="gb_5d gb_2c" style="user-select: auto;">വാർത്തകൾ</span></a></div>
					</div>
					<div class="gb_Ld gb_ya gb_1c gb_2c" style="user-select: auto;"><span class="gb_5c" aria-level="1" role="heading" style="user-select: auto;"></span></div>
				</div>
				<div class="gb_Ld gb_Vd gb_He gb_Ee gb_Ke" style="user-select: auto;">
					<div class="gb_Fe" style="user-select: auto;">
						<form class="gb_Te gb_Ee VISqTe" method="get" role="search" style="user-select: auto;">
							<button class="gb_pf" aria-label="തിരയൽ അടയ്&zwnj;ക്കുക" type="button" style="user-select: auto;">
								<svg focusable="false" height="24px" viewBox="0 0 24 24" width="24px" xmlns="http://www.w3.org/2000/svg" style="user-select: auto;">
									<path d="M0 0h24v24H0z" fill="none" style="user-select: auto;"></path>
									<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" style="user-select: auto;"></path>
								</svg>
							</button>
							<div class="gb_uf" style="user-select: auto;">
								<div class="gb_ef gb_vf" style="user-select: auto;">
									<div class="TMT2L" jscontroller="U4Hp0d" jsaction="rcuQ6b:rcuQ6b;fRPOBb:ti6hGc;isz31c:ZYIfFd;" style="user-select: auto;">
										<div class="Mxgq5c" jsname="haAclf" jscontroller="MxVzvd" jsaction="CLIdJb:MN2rZe;v819Lb:NLjNtd;fRPOBb:JFZiG;rcuQ6b:npT2md;wmWsCf:KuiYke;" style="user-select: auto;">
											<div class="L6J0Pc VOEIyf g4E9Cb Yonv" jscontroller="Mq9n0c" jsaction="keydown:I481le; focus: AHmuwe;AHmuwe:AHmuwe; mouseenter:npT2md;Mu8aMc:YPqjbf;Edq9ub:SDqDXe;e0gSlf:pX1iqf;" data-close-on-blur="true" jsname="h0T7hb" data-renderer="g2JDKf" data-service="VkjdHd" style="user-select: auto;">
												<div class="d1dlne" jscontroller="K99qY" jsname="YPqjbf" style="position: relative; user-select: auto;" data-placeholder="തിരയുക" data-activedescendants="true">
													<input class="yNVtPc ZAGvjd Ny5lGc" disabled="true" aria-hidden="true" jsname="A51lKb" value="തിരയുക" dir="ltr" style="user-select: auto;">
													<input class="Ax4B8 ZAGvjd" type="text" autocomplete="off" aria-label="തിരയുക" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" role="combobox" jsname="dSO9oc" jsaction="input:YPqjbf; keydown:I481le; click:cOuCgd" aria-controls="nngdp367" style="user-select: auto;">
												</div>
												<div class=" tWfTvb" style="user-select: auto;">
													<div class="u3WVdc jBmls" tabindex="-1" role="listbox" data-expanded="false" data-childcount="0" jsname="iuXDpb" jsaction="mousedown:npT2md(preventDefault=true);" id="nngdp367" style="user-select: auto;"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<button class="gb_qf" aria-label="തിരയല്&zwj;&zwnj; മായ്&zwnj;ക്കുക" type="button" style="user-select: auto;">
								<svg focusable="false" height="24px" viewBox="0 0 24 24" width="24px" xmlns="http://www.w3.org/2000/svg" style="user-select: auto;">
									<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" style="user-select: auto;"></path>
									<path d="M0 0h24v24H0z" fill="none" style="user-select: auto;"></path>
								</svg>
							</button>
							
							<div style="display: none; user-select: auto;"></div>
						<div style="display: none;"></div></form>
					</div>
				</div>
				<div class="gb_Wd gb_Za gb_Ld" ng-non-bindable="" data-ogsr-up="" style="user-select: auto;">
					<div class="gb_Se" style="user-select: auto;">
						<div class="gb_Tc" style="user-select: auto;">
							<div class="gb_z gb_hd gb_f gb_Af" data-ogsr-fb="true" data-ogsr-alt="" id="gbwa" style="user-select: auto;">
								<div class="gb_zf" style="user-select: auto;">
									<a class="gb_A" aria-label="Google ആപ്സ്" href="https://www.google.co.in/intl/ml/about/products?tab=nh" aria-expanded="false" role="button" tabindex="0" style="user-select: auto;">
										<svg class="gb_Ve" focusable="false" viewBox="0 0 24 24" style="user-select: auto;">
											<path d="M6,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,20c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM6,20c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM6,14c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,14c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM16,6c0,1.1 0.9,2 2,2s2,-0.9 2,-2 -0.9,-2 -2,-2 -2,0.9 -2,2zM12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM18,14c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM18,20c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2z" style="user-select: auto;"></path>
										</svg>
									</a>
								</div>
							</div>
						</div>
						
					</div>
					<div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 328px; z-index: 991; height: 0px; margin-top: 57px; transition: height 0.3s ease-in-out 0s; right: 0px; margin-right: 4px; user-select: auto;"></div>
					<div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 372px; z-index: 991; height: 0px; margin-top: 57px; right: 0px; margin-right: 4px; user-select: auto;"></div>
				<div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 328px; z-index: 991; height: 0px; margin-top: 57px; transition: height 0.3s ease-in-out 0s; right: 0px; margin-right: 4px;"></div><div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 372px; z-index: 991; height: 0px; margin-top: 57px; right: 0px; margin-right: 4px;"></div>

					<!-- Nabeel -->
				<div style="display: none;overflow: hidden; position: absolute; top: 0px; width: 100%; z-index: 991; height: 448px; margin-top: 57px; transition: height 0.3s ease-in-out 0s; right: 0px; margin-right: 0px; max-height: calc(-61px + 100vh);">

					<div style="box-shadow:0 -1px 2px 0 rgba(60,64,67,0.30),0 -2px 6px 2px rgba(60,64,67,0.15);height:calc(100% - 16px);left:0;margin:8px;position:absolute;top:0;width:calc(100% - 16px);background:#FFF;"><div style="font:14px/22px Roboto,RobotoDraft,Arial,sans-serif;letter-spacing:0.03px;padding:134px 50px;text-align:center;white-space:normal;color:#5F6368;" data-fb=""> <svg height="28px" viewBox="0 0 24 24" width="28px" xmlns="http://www.w3.org/2000/svg"> <path fill="#80868B" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path> </svg> <p style="margin-top:4px;"> ആപ്പുകളുടെ ഗണം ലോഡ് ചെയ്യുന്നതിൽ ഒരു പ്രശ്&amp;zwnj;നമുണ്ടായി. അൽപ്പസമയത്തിന് ശേഷം വീണ്ടും ശ്രമിക്കുകയോ  <a style="font:14px/22px Roboto,RobotoDraft,Arial,sans-serif;font-weight:bold;letter-spacing:0.03px;text-decoration:none;color:#4285F4;" target="_blank" href="https://www.google.co.in/intl/ml/about/products?tab=nh">Google ഉൽപ്പന്നങ്ങൾ</a>  പേജിലേക്ക് പോകുകയോ ചെയ്യുക. </p> </div></div></div><div style="overflow: hidden; position: absolute; top: 0px; visibility: hidden; width: 372px; z-index: 991; height: 0px; margin-top: 57px; right: 0px; margin-right: 4px;"></div></div>
			</div>
			<div class="gb_Td gb_3d" style="user-select: auto;"></div>
		</header>
		<div class="gb_Pd" style="height: 56px; user-select: auto;"></div>
	</div>
	
	<p><a href="tel:+4733378901">+47 333 78 901</a>
	<br><br>
	<a href="https://wa.me/919846994295">Open WhatsApp</a>
	<br><br>
	<a href="sms:919846994295">Open Message</a>
	<br><br>
	<a href="https://goo.gl/maps/k9wkbXPBhGqt4PXMA">Open Google map</a>
	<br><br>
	<a href="https://www.youtube.com/watch?v=9hPzMkYmArQ">Open YouTube</a>
	</p>
	
	<c-wiz jsrenderer="qeKLuc" class="zQTmif SSPGKf ZYcfVd oCHqfe JwkDRc BIIBbc" jsdata="deferred-i1" data-p="%.@.[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,3,[],[],1]" jsname="a9kxte" data-node-index="0;0" jsmodel="hc6Ubd" view="" c-wiz="" data-ogpc="" style="user-select: auto; position: fixed; inset: -191px 0px -2374px; display: none; visibility: hidden; opacity: 0;" data-savedfocusid="150" data-savescroll="191" aria-busy="true" aria-hidden="true">
		<div class="T4LgNb" jsname="a9kxte" style="user-select: auto;">
			<div class="VjFXz" style="user-select: auto;"></div>
			<div class="FVeGwb CVnAc Haq2Hf bWfURe" jscontroller="BeJYtf" jsaction="rcuQ6b:npT2md;kfsncb:QnC63e;" jslog="83496; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLDE0MSxudWxsLG51bGwsbnVsbCwzMDFd; track:vis" data-n-et="422" jsmodel="FSc7tf lPJ2ac" style="user-select: auto;">
				<div jsname="ReIlqe" data-n-pt="6" style="user-select: auto;"></div>
				<div class="ajwQHc BL5WZb zLBZs" style="user-select: auto;">
					<div class="tsldL Oc0wGc" style="user-select: auto;">
						<main class="HKt8rc CGNRMc" jsname="fjw8sb" jslog="94187; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLDE0MSxudWxsLG51bGwsbnVsbCwzMDFd" style="user-select: auto;">
							<div jscontroller="fAYBsd" jsaction="rcuQ6b:npT2md" style="user-select: auto;"></div>
							<c-wiz jsrenderer="OIIjLd" class="FTc2fd" data-n-nap="1" data-n-prms="[null,6,1,false,3,[],null,[1],null]" jsdata="deferred-i2" data-p="%.@.[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,null,null,3,[],[],1]" jscontroller="o8u3Cf" jsaction="rcuQ6b:npT2md;" data-node-index="1;0" jsmodel="hc6Ubd Hjkoe" c-wiz="" style="user-select: auto;">
								<div class="lBwEZb BL5WZb xP6mwf ENDuKc Au3bp" jsname="esK7Lc" jscontroller="SpTAFc" jsmodel="dPwZPd hT8rr" jsdata="tbf4if;ui|124+510ac017-3647-4d8e-b3fc-6c870295f0ba,ui|124+97547700-ce26-4b96-a438-026664df258b;4" data-n-et="200" data-n-ham="true" style="user-select: auto;">
									<div jslog="88374; 3:W251bGwsbnVsbCxudWxsLG51bGwsInNlY3Rpb24tdG9waWMtbWlkOi9tLzA1amhnIixudWxsLDE0MSxudWxsLG51bGwsbnVsbCwzMDEsbnVsbCxudWxsLFtbWyIvbS8wNWpoZyJdXSxudWxsLDhdXQ==; track:vis ; index:0" class="iKGKEb tXImLc Oc0wGc lBwEZb Au3bp sfxiOc R7GTQ keNKEd " style="user-select: auto;">
										<div class="dSva6b JQQdOc  yETrXb Ir3o3e Au3bp sbWPef R7GTQ keNKEd j7vNaf " data-n-hl="ml" jsdata="tbf4if;ui|124+942c1b1e-d0b2-42e0-a166-4d9c0e43bb22,ui|124+684daa0c-e30c-43bf-a51a-118bdc065f19;5" jsmodel="hT8rr" data-n-ham="true" id="i3" style="user-select: auto;">
											<div class="cp7Yvc" style="user-select: auto;">
												<h2 class="oOr8M  yETrXb Ir3o3e Au3bp cS3HJf" jsname="smh91d" style="user-select: auto;"><span jscontroller="MfVatf" jsaction="click:KjsqPd" jslog="108423; 3:W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtudWxsLCJDQUFxSmdnS0lpQkRRa0ZUUldkdlNVd3lNSFpOUkZaeFlVZGpVMEZ0TVhOSFowcEtWR2xuUVZBQiJdXQ==" data-n-et="1501" data-n-ca-at="1" data-n-ci-wu="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRFZxYUdjU0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" style="user-select: auto;"><a href="./topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRFZxYUdjU0FtMXNHZ0pKVGlnQVAB?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="wmzpFf  yETrXb Ir3o3e Au3bp ndj7Ed" style="user-select: auto;">തലക്കെട്ടുകൾ</a></span></h2></div>
										</div>
										<div class="NWHX8c pOFxF Au3bp mi8Lec  R7GTQ keNKEd j7vNaf" jsmodel="analyticsModelWiz.id" data-n-et="1605" data-n-ham="true" data-n-cvid="i5" jsdata="tbf4if;ui|124+f080fcab-ca35-4c71-8f0b-972c96ee3b4b,ui|124+4595ee9b-e581-41c8-8c6e-110ef31377eb;6" jslog="127548; 3:W251bGwsbnVsbCxudWxsLG51bGwsImNoYW5uZWxfc3RvcnlfMzYwOkNBQXFOZ2dLSWpCRFFrbFRTR3B2U21NelVuWmpibXQwVFhwWmQxTm9SVXRFZDJvM01FNWhWa0pTU0hORmJqZGFVVlJtVUVKRFowRlFBUSIsbnVsbCwxNDEsbnVsbCxudWxsLG51bGwsMzAxLG51bGwsbnVsbCxbW1siL20vMDVqaGciXV0sMSw0XV0=; track:vis; index:0" style="user-select: auto;">
											
										<div data-n-et="1606" data-n-ham="true" data-n-cvid="i7" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;8" jsmodel="hT8rr" jscontroller="w22xSc" jsaction="rcuQ6b:npT2md;" style="user-select: auto;">
											<div class="SJyhnc PqkbTd" jsshadow="" style="user-select: auto;">
												<div jsslot="" class="NBZP0e xbmkib" jscontroller="XTf4dd" jsaction="" data-snap-point="0" data-snap-debounce-ms="250" data-snap-animation-ms="300" jslog="126735; 3:W10=; track:vis; index:1" style="user-select: auto;">
													<article class=" MQsxIb xTewfe FSATdd Au3bp EjqUne msTxEe" jscontroller="HyhIue" jsaction=";rcuQ6b:npT2md; click:KjsqPd;" jsmodel="a4N6Ae hT8rr" jslog="85008; 3:W251bGwsbnVsbCxudWxsLG51bGwsImNoYW5uZWxfc3RvcnlfMzYwOkNBQXFOZ2dLSWpCRFFrbFRTR3B2U21NelVuWmpibXQwVFhwWmQxTm9SVXRFZDJvM01FNWhWa0pTU0hORmJqZGFVVlJtVUVKRFowRlFBUSIsMCwxNDEsbnVsbCxudWxsLFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLCJhOWI0N2M5Ny00MTZlLTRlZmQtODEzZC05NTc5MWQ0Njc0MzAiXSwzMDEsbnVsbCxudWxsLFtbWyIvbS8wNWpoZyJdXSwxLDRdLG51bGwsMV0=; track:vis; index:0" ve-visible="false" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;8" data-kind="2" data-n-ham="true" data-n-et="107" data-n-cvid="i8" data-n-vlb="0" data-n-suav="true" style="user-select: auto;">
														<a class="VDXfz" jsname="hXwDdf" jslog="95014; 5:W251bGwsbnVsbCwiaHR0cHM6Ly93d3cubWF0aHJ1Ymh1bWkuY29tL2NyaW1lL25ld3MvcGFsYWtrYWQtc3JlZW5pdmFzYW4tbXVyZGVyLWNhc2UtZXZpZGVuY2UtdGFraW5nLXdpdGgtYWNjdXNlZC0xLjc0NjMwNzkiLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCwiaHR0cHM6Ly93d3cubWF0aHJ1Ymh1bWkuY29tL2FtcC9jcmltZS9uZXdzL3BhbGFra2FkLXNyZWVuaXZhc2FuLW11cmRlci1jYXNlLWV2aWRlbmNlLXRha2luZy13aXRoLWFjY3VzZWQtMS43NDYzMDc5Il0=; track:click,vis" href="https://google.com" tabindex="-1" aria-hidden="true" style="user-select: auto;"></a>
														<div class="wsLqz RD0gLb Rgstwe" style="user-select: auto;"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme IGhidc" srcset="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=s0-h14-rw 1x, https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=s0-h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=s0-h14-rw" loading="lazy" style="user-select: auto;"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme b1F67d" srcset="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=s0-h14-rw 1x, https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=s0-h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=s0-h14-rw" loading="lazy" style="user-select: auto;"><img class="tvs3Id tvs3Id lqNvvd lITmO WfKKme" jsname="mgY0Ed" srcset="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=s0-h24-rw 1x, https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=s0-h48-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=s0-h24-rw" loading="lazy" style="user-select: auto;"><a href="./publications/CAAqBggKMLqiLTCnmQU?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="wEwyrc AVN2gc WfKKme " data-n-tid="9" style="user-select: auto;">Mathrubhumi</a></div>
														<h5 class="ipQwMb ekueJc RD0gLb" style="user-select: auto;"><a href="https://google.com" class="DY5T1d RZIKme" style="user-select: auto;">ശ്രീനിവാസന്&zwj; വധക്കേസ്: പ്രതിയുമായി തെളിവെടുപ്പ്, സ്&zwnj;കൂട്ടര്&zwj; കണ്ടെടുത്തു</a></h5>
														<div class="QmrVtf RD0gLb kybdz" style="user-select: auto;">
															<div class="SVJrMe" jsname="Hn1wIf" style="user-select: auto;">
																<svg height="18" viewBox="0 0 24 24" width="18" focusable="false" class="N3ElHc eLNT1d uQIVzc NMm5M" style="user-select: auto;">
																	<path d="M0 0h24v24H0V0z" fill="none" style="user-select: auto;"></path>
																	<path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z" style="user-select: auto;"></path>
																</svg>
																<time class="WW6dff uQIVzc Sksgp" datetime="2022-04-25T09:01:48Z" style="user-select: auto;">9 മണിക്കൂർ മുമ്പ്</time>
															</div>
															<menu class="fmkQje gXqRq" style="user-select: auto;"><span class=" L8PZAb GB1Zid" jscontroller="jSvZHb" jsmodel="WDTLsd BZ12ub" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;8 tbf4if;ui|124+f080fcab-ca35-4c71-8f0b-972c96ee3b4b,ui|124+4595ee9b-e581-41c8-8c6e-110ef31377eb;6" jsaction="rcuQ6b:npT2md;aWRkAb:u0WEMd;h4C2te:Oy8cwd;" data-n-prms="[true,true,false,null,false,false,false,false,null,false,true]" jslog="109017" style="user-select: auto;"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e uUmIDd gL67me cd29Sd V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="S9Bhuc" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="കൂടുതൽ&zwj;" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-dynamic="true" style="user-select: auto;"><div class="XI1L0d zSBur" jsname="ksKsZd" style="user-select: auto;"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job" style="user-select: auto;">more_vert</span></div>
														</span>
														</menu>
												</div>
												</article>
												
				
		
		</div>
		</div>
		<div class="FGOkNb" jsname="Hzufd" style="user-select: auto;"></div>
		<div class="MH4CV" jsaction="ZYIfFd:QdqIqe" style="user-select: auto;">
			<div class="EmVfjc CxE4Ze eLNT1d" data-loadingmessage="ലോഡുചെയ്യുന്നു..." jscontroller="qAKInc" jsaction="animationend:kWijWc;dyRcpb:dyRcpb" jsname="aZ2wEe" data-active="false" style="user-select: auto;">
				<div class="Cg7hO" aria-live="assertive" jsname="vyyg5" style="user-select: auto;"></div>
				<div jsname="Hxlbvc" class="xu46lf" style="user-select: auto;">
					<div class="ir3uv uWlRce co39ub" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
					<div class="ir3uv GFoASc Cn087" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
					<div class="ir3uv WpeOqd hfsr6b" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
					<div class="ir3uv rHV3jf EjXFBf" style="user-select: auto;">
						<div class="xq3j6 ERcjC" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="HBnAAc" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
						<div class="xq3j6 dj3yTd" style="user-select: auto;">
							<div class="X6jHbb GOJTSe" style="user-select: auto;"></div>
						</div>
					</div>
				</div>
			</div>
		</div>

			<div class="ajwQHc BL5WZb">
				<div class="tsldL Oc0wGc">
					<main class="HKt8rc CGNRMc" jsname="fjw8sb">
						<c-wiz jsrenderer="optrU" class="Vlf0vb" jslog="" data-n-et="405" data-n-ham="true" data-n-prms="[8,1,false,false,3,0,false]" jsdata="deferred-c8" data-p="%.@.null,null,&quot;CAAqNggKIjBDQklTSGpvSmMzUnZjbmt0TXpZd1NoRUtEd2o3ME5hVkJSSHNFbjdaUVRmUEJDZ0FQAQ&quot;,false,[[&quot;ml&quot;,&quot;IN&quot;,[&quot;SPORTS_FULL_COVERAGE&quot;,&quot;WEB_TEST_1_0_0&quot;],null,[],2,1,&quot;IN:ml&quot;,null,330],&quot;ml&quot;,&quot;IN&quot;,false,[2,3,4,28],1,false,&quot;443906232&quot;,false,true],null,null,0,3,null,false,true]" jscontroller="uzO99c" jsaction="rcuQ6b:npT2md;wQCqwd:vNq42e;" data-node-index="1;0" jsmodel="hc6Ubd be99Xd hT8rr" c-wiz="">
							<div class="ajwQHc BL5WZb">
								<div class="tsldL Oc0wGc">
									<main class="HKt8rc CGNRMc" jsname="fjw8sb" jslog="134946">
										<div class="lBwEZb BL5WZb xP6mwf ENDuKc Au3bp" jsname="esK7Lc" jscontroller="SpTAFc" jsmodel="dPwZPd hT8rr" jsdata="tbf4if;CAQiZ0NCSVNSem9KYzNSdmNua3RNell3UWdodmRtVnlkbWxsZDBvUkNnOEktOURXbFFVUjdCSi0yVUUzendSeUhRb2JDaGxUVkU5U1dWOHpOakJmU0VWQlJFVlNYMDlXUlZKV1NVVlhLQUEqOggAKjYICiIwQ0JJU0hqb0pjM1J2Y25rdE16WXdTaEVLRHdqNzBOYVZCUkhzRW43WlFUZlBCQ2dBUAFQAQ,;$2" data-n-et="200" data-n-ham="true">
											<div class="w0Adec Oc0wGc lMgtcc R7GTQ keNKEd j7vNaf " jslog="88374; 3:W251bGwsbnVsbCxudWxsLG51bGwsIk5FV1NfVE9QX0NPVkVSQUdFX1JFU1VMVF9HUk9VUCIsbnVsbCwxNDEsbnVsbCxudWxsLG51bGwsNTksbnVsbCxudWxsLFtdLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLFtdXQ==; track:vis; index:0" data-n-tid="14">
												<div class="pjBVq mi8Lec D6Jf dIgQgd EOlQu Oc0wGc Au3bp R7GTQ keNKEd j7vNaf" jsmodel="hT8rr" jsdata="KX46Ye;_;$3" data-n-ham="true">
													<!-- <div class="dSva6b JQQdOc  yETrXb Ir3o3e Au3bp sbWPef R7GTQ keNKEd j7vNaf " data-n-hl="ml" jsdata="tbf4if;ui|124+10adb768-9313-425c-b83f-0798fe1d98a7,ui|124+e599066d-71a6-40b5-be7e-8ee4631e8042;$4" jsmodel="hT8rr" data-n-ham="true" id="c1">
														<div class="cp7Yvc">
															<h2 class="oOr8M  yETrXb Ir3o3e Au3bp cS3HJf" jsname="smh91d">പ്രധാന വാർത്തകൾ</h2></div>
													</div> -->
													<div class="ndSf3d eDrqsc eVhOjb Oc0wGc j7vNaf dIgQgd" jsname="gKDw6b">

														<!-- Nabeel -->
														<article class=" MQsxIb xTewfe tXImLc Xpocq R7GTQ keNKEd keNKEd Au3bp VkAdve GU7x0c g1F8Ld mSjmrf msTxEe" jscontroller="HyhIue" jsaction=";rcuQ6b:npT2md; click:KjsqPd;" jsmodel="a4N6Ae hT8rr" jslog="85008; 3:W251bGwsbnVsbCxudWxsLG51bGwsIk5FV1NfVE9QX0NPVkVSQUdFX1JFU1VMVF9HUk9VUCIsMCwxNDEsbnVsbCxudWxsLG51bGwsNTksbnVsbCxudWxsLFtdLG51bGwsMSxudWxsLG51bGwsbnVsbCxudWxsLFtdXQ==; track:vis; index:0" ve-visible="true" jsdata="oM6qxc;CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s;$5" data-kind="13" data-n-ham="true" data-n-et="107" data-n-cvid="c2" data-n-vlb="0" data-n-suav="true">
															<a class="VDXfz" jsname="hXwDdf" jslog="95014; 5:W251bGwsbnVsbCwiaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmh0bWwiLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCwiaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1sIixudWxsLG51bGwsW11d; track:click,vis" href="./articles/CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" tabindex="-1" aria-hidden="true"></a>
															<figure jscontroller="dAR81" jsaction="error:HLDri" class="AZtY5d fvuwob  RD0gLb"><img class="tvs3Id QwxBBf" srcset="https://lh3.googleusercontent.com/proxy/ku0sL0ViPLR5dnjGqhIDoba3Ls9uIRd5xNphHJE_qJJQQ0YtziWqDK9-R6v4XMGpTdTedKQnAFMFmcR9z5aubncYfL0TVOgtU_wPcGZlyMic47D6NwdNO9NPb7e41zT0Szdtur90zAdpuGXBCUHHOuAl2GQeD-0lRPx3lhXzgpETXsW3QRiv9zjlOa1_HTRnSYyF-zPj9NAyGpG_d3hxkws=w350-h175-rw-dcDYCUSLQH 1x, https://lh3.googleusercontent.com/proxy/ku0sL0ViPLR5dnjGqhIDoba3Ls9uIRd5xNphHJE_qJJQQ0YtziWqDK9-R6v4XMGpTdTedKQnAFMFmcR9z5aubncYfL0TVOgtU_wPcGZlyMic47D6NwdNO9NPb7e41zT0Szdtur90zAdpuGXBCUHHOuAl2GQeD-0lRPx3lhXzgpETXsW3QRiv9zjlOa1_HTRnSYyF-zPj9NAyGpG_d3hxkws=w700-h350-rw-dcDYCUSLQH 2x" aria-label="ഇമേജ്" alt="" src="https://lh3.googleusercontent.com/proxy/ku0sL0ViPLR5dnjGqhIDoba3Ls9uIRd5xNphHJE_qJJQQ0YtziWqDK9-R6v4XMGpTdTedKQnAFMFmcR9z5aubncYfL0TVOgtU_wPcGZlyMic47D6NwdNO9NPb7e41zT0Szdtur90zAdpuGXBCUHHOuAl2GQeD-0lRPx3lhXzgpETXsW3QRiv9zjlOa1_HTRnSYyF-zPj9NAyGpG_d3hxkws=w350-h175-rw-dcDYCUSLQH" importance="high" jslog="131347" loading="lazy"></figure>
															<div class="wsLqz RD0gLb"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme IGhidc" srcset="https://lh3.googleusercontent.com/iu2FMOg_Yf2g0ydlI9pw1H8fIrB5hClaFB-XFiDdNqXGiAhe5urQEwQYNxKKuGvdNrXa1KVrew=h14-rw 1x, https://lh3.googleusercontent.com/iu2FMOg_Yf2g0ydlI9pw1H8fIrB5hClaFB-XFiDdNqXGiAhe5urQEwQYNxKKuGvdNrXa1KVrew=h28-rw 2x" aria-label="ഇമേജ് - Manorama Online" alt="Manorama Online" src="https://lh3.googleusercontent.com/iu2FMOg_Yf2g0ydlI9pw1H8fIrB5hClaFB-XFiDdNqXGiAhe5urQEwQYNxKKuGvdNrXa1KVrew=h14-rw" loading="lazy"><img class="tvs3Id tvs3Id lqNvvd lITmO WfKKme" jsname="mgY0Ed" srcset="https://encrypted-tbn0.gstatic.com/faviconV2?url=https://www.manoramaonline.com&amp;client=NEWS_360&amp;size=96&amp;type=FAVICON&amp;fallback_opts=TYPE,SIZE,URL 1x, https://encrypted-tbn0.gstatic.com/faviconV2?url=https://www.manoramaonline.com&amp;client=NEWS_360&amp;size=96&amp;type=FAVICON&amp;fallback_opts=TYPE,SIZE,URL 2x" aria-label="ഇമേജ് - Manorama Online" alt="Manorama Online" src="https://encrypted-tbn0.gstatic.com/faviconV2?url=https://www.manoramaonline.com&amp;client=NEWS_360&amp;size=96&amp;type=FAVICON&amp;fallback_opts=TYPE,SIZE,URL" loading="lazy"><a class="wEwyrc AVN2gc WfKKme " data-n-tid="9">Manorama Online</a></div>
															<h4 class="ipQwMb ekueJc RD0gLb"><a href="./articles/CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="DY5T1d RZIKme">പാലക്കാട് എസ്&zwj;ഡിപിഐ ഓഫിസില്&zwj; റെയ്ഡ്; ചില രേഖകൾ കിട്ടിയെന്ന് പൊലീസ്</a></h4>
															<div class="QmrVtf RD0gLb kybdz">
																<div class="SVJrMe" jsname="Hn1wIf">
																	<svg height="18" viewBox="0 0 24 24" width="18" focusable="false" class="N3ElHc eLNT1d uQIVzc NMm5M">
																		<path d="M0 0h24v24H0V0z" fill="none"></path>
																		<path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"></path>
																	</svg>
																	<time class="WW6dff uQIVzc Sksgp" datetime="2022-04-25T15:35:12Z">2 മണിക്കൂർ മുമ്പ്</time>
																</div>
																<menu class="fmkQje gXqRq"><span class=" L8PZAb GB1Zid" jscontroller="jSvZHb" jsmodel="WDTLsd BZ12ub" jsdata="oM6qxc;CBMiXGh0dHBzOi8vd3d3Lm1hbm9yYW1hb25saW5lLmNvbS9uZXdzL2xhdGVzdC1uZXdzLzIwMjIvMDQvMjUvc2RwaS1vZmZpY2UtcmFpZC1hdC1wYWxha2thZC5odG1s0gFgaHR0cHM6Ly93d3cubWFub3JhbWFvbmxpbmUuY29tL25ld3MvbGF0ZXN0LW5ld3MvMjAyMi8wNC8yNS9zZHBpLW9mZmljZS1yYWlkLWF0LXBhbGFra2FkLmFtcC5odG1s;$6 tbf4if;ui|124+10adb768-9313-425c-b83f-0798fe1d98a7,ui|124+e599066d-71a6-40b5-be7e-8ee4631e8042;$7" jsaction="rcuQ6b:npT2md;aWRkAb:u0WEMd;h4C2te:Oy8cwd;" data-n-prms="[true,true,false,null,false,false,false,false,null,false,false]" jslog="109017"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e uUmIDd gL67me cd29Sd V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="S9Bhuc" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="കൂടുതൽ&zwj;" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-dynamic="true"><div class="XI1L0d zSBur" jsname="ksKsZd"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job">more_vert</span></div>
															</span>
															</menu>
													</div>
													</article>

<?php 
    
    if($dbQueries->Query("SELECT * FROM mannarkkad")) {
                           
        $totalRecords = $dbQueries->rowCount();
        $dbQueries->Query("SELECT * FROM mannarkkad LIMIT 0,10");
                           
        $newses = $dbQueries->fetchAll();
        $rowCount = $dbQueries->rowCount();
                           
    if($rowCount > 0){
                           
        foreach($newses as $id=>$news) { ?>
            									
												
											<article class=" MQsxIb xTewfe tXImLc R7GTQ keNKEd keNKEd Au3bp VkAdve GU7x0c JMJvke q4atFc msTxEe">
												<a class="VDXfz" tabindex="-1" aria-hidden="true" href="<?php echo $news->link; ?>"></a>
												<figure jscontroller="dAR81" jsaction="error:HLDri" class="AZtY5d fvuwob  RD0gLb"><img class="tvs3Id QwxBBf" srcset="<?php echo $news->image; ?> 2x" aria-label="ഇമേജ്" alt="" src="<?php echo $news->image; ?>" loading="lazy"></figure>
												<div class="wsLqz RD0gLb"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme IGhidc" srcset="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=h14-rw 1x, https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/Zl5E7sqOta0pVBUlQA-ZA2ZlaYHrAB2nJm-7e8Tv6poeu-5XMAvBR-w8a78w66SBRPPOez1_=h14-rw" loading="lazy"><img class="tvs3Id tvs3Id lqNvvd ICvKtf WfKKme b1F67d" srcset="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=h14-rw 1x, https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=h28-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/REM2ahft89EtS8YzmWEBvaZBebEPHfsLvZxAJ6hMohlUjokWA-41n1WyrvMf2ukuHOXWgSe_ew=h14-rw" loading="lazy"><img class="tvs3Id tvs3Id lqNvvd lITmO WfKKme" jsname="mgY0Ed" srcset="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=h24-rw 1x, https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=h48-rw 2x" aria-label="ഇമേജ് - Mathrubhumi" alt="Mathrubhumi" src="https://lh3.googleusercontent.com/ggAbWL8aitecoCMAkOZefWFcB8-pba-qZAid-jP0gIJU_KrCaQgh63azP6VskRnh9wuyxPZUDpCIGm-uhZs=h24-rw" loading="lazy"><a href="./publications/CAAqBggKMLqiLTCnmQU?hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="wEwyrc AVN2gc WfKKme " data-n-tid="9">Mathrubhumi</a></div>
												<h4 class="ipQwMb ekueJc RD0gLb"><a href="./articles/CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk?uo=CAUiANIBAA&amp;hl=ml&amp;gl=IN&amp;ceid=IN%3Aml" class="DY5T1d RZIKme"><?php echo $news->title; ?></a></h4>
												<div class="QmrVtf RD0gLb kybdz">
													<div class="SVJrMe" jsname="Hn1wIf">
														<svg height="18" viewBox="0 0 24 24" width="18" focusable="false" class="N3ElHc eLNT1d uQIVzc NMm5M">
															<path d="M0 0h24v24H0V0z" fill="none"></path>
															<path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"></path>
														</svg>
														<time class="WW6dff uQIVzc Sksgp" datetime="2022-04-25T09:01:48Z">9 മണിക്കൂർ മുമ്പ്</time>
													</div>
													<menu class="fmkQje gXqRq"><span class=" L8PZAb GB1Zid" jscontroller="jSvZHb" jsmodel="WDTLsd BZ12ub" jsdata="oM6qxc;CAIiEBxs1893iWriEFyRFfnHdkkqFggEKg4IACoGCAowuqItMKeZBTDRngk;$15 tbf4if;ui|124+10adb768-9313-425c-b83f-0798fe1d98a7,ui|124+e599066d-71a6-40b5-be7e-8ee4631e8042;$16" jsaction="rcuQ6b:npT2md;aWRkAb:u0WEMd;h4C2te:Oy8cwd;" data-n-prms="[true,true,false,null,false,false,false,false,null,false,false]" jslog="109017"><div role="button" class="U26fgb YOnsCc waNn5b ZqhUjb ztUP4e uUmIDd gL67me cd29Sd V3dfMc lSLCF MDgEWb  M9Bg4d" jscontroller="S9Bhuc" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue; focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;;keydown:I481le;OuuAFc:UauMyf;gSufsc:BS8cLb;RyWlBb:tC9Erd;UTnG9:aDaYxb;nUyoxf:El6wk;" jsshadow="" jsname="itaskb" aria-label="കൂടുതൽ&zwj;" aria-disabled="false" tabindex="0" aria-haspopup="true" aria-expanded="false" data-dynamic="true"><div class="XI1L0d zSBur" jsname="ksKsZd"></div><span class="DPvwYc ChwdAb Xd067b fAk9Qc" aria-hidden="true" jsname="BC5job">more_vert</span></div>
												</span>
												</menu>
										</div>
	
										</article>
<?php
    
        }
    }
   
  }  
?>	

								</div>
							</div>
				</div>
				
				<div class="dSva6b JQQdOc  yETrXb Ir3o3e Au3bp R7GTQ keNKEd j7vNaf" data-n-hl="ml" jslog="134728; index:1" jsdata="AFn1Dc;;$17" jsmodel="hT8rr" data-n-ham="true">
					
				</div>
				
		</div>
		<!--Nabeel-->
		<div class="TleV1d" jsname="Hzufd">
			<div class="MH4CV" jsaction="ZYIfFd:QdqIqe">
				<div class="EmVfjc CxE4Ze eLNT1d" data-loadingmessage="ലോഡുചെയ്യുന്നു..." jscontroller="qAKInc" jsaction="animationend:kWijWc;dyRcpb:dyRcpb" style="display:block;">
					<div class="Cg7hO" aria-live="assertive" jsname="vyyg5"></div>
					<div jsname="Hxlbvc" class="xu46lf">
						
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: rgb(255, 255, 255); display: block; user-select: auto; shape-rendering: auto;" width="48px" height="48px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
							<circle cx="50" cy="50" fill="none" stroke="#e15b64" stroke-width="7" r="35" stroke-dasharray="164.93361431346415 56.97787143782138" style="user-select: auto;">
							  <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" values="0 50 50;360 50 50" keyTimes="0;1" style="user-select: auto;"></animateTransform>
							</circle></svg>

					</div>
				</div>
			</div>
		</div>
		</main>
		</div>
		</div>

</body></html>