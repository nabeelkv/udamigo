 <title>Adding Cron Data</title>
<?php
 include("init.php");
 $dbQueries = new dbQueries;
 $currentDateTime = date("Y-m-d H:i:s");
 
 
    $title = 'THIS DATA ADDED BY CRRRRRRRONNNNNNN ON '.$currentDateTime.'!!!!!!';
    $created = $currentDateTime;
    // echo $site_html;

 
//adding data
 if($dbQueries->Query("INSERT INTO data(title, createdAt) VALUES (?, ?)", [$title, $created])) {

	 echo "<p><span style='color:green'>Data added!</span></p>";

  } else {

	 echo "<span style='color:red'>Data couldn't added. Try again!</span>";

  } 
        
?>