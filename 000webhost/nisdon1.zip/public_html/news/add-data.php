<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adding Data</title>
<?php
  error_reporting(0);
 include("init.php");
 include("simple_html_dom.php");
 $dbQueries = new dbQueries;
 $currentDateTime = date("Y-m-d H:i:s");
 
 $url = 'https://www.worldtimeserver.com/current_time_in_IN.aspx';
 
 // Machine start here
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url); // target
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // provide a user-agent
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow any redirects
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // return the result
    $result = curl_exec($ch);
    curl_close($ch);
    $site_html = str_get_html($result);
    ///////////////////////////////////////
    
    $title = $_GET['title'];
 

    // echo $title = $site_html->find('#theTime')[0]->innertext;
    $created = $currentDateTime;
    // echo $site_html;

 
//adding data
 if($dbQueries->Query("INSERT INTO data(title, createdAt) VALUES (?, ?)", [$title, $created])) {

	 echo "<p><span style='color:green'>Data added!</span></p>";

  } else {

	 echo "<span style='color:red'>Data couldn't added. Try again!</span>";

  } 
        
?>