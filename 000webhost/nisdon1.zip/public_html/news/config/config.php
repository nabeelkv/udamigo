<?php 

	define("HOST", "localhost");
	define("USER", "id19203974_nabeelu");
	define("DB", "id19203974_nabeel");
	define("PASSWORD", "x>nSh4b?9Ih{kC4l");

 ?>